package com.mycompany.prototipo_pi.Models;

import com.mycompany.prototipo_pi.DAO.UserDAO;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author R I C H
 */
public class userTableModel extends AbstractTableModel {

    private List<User> users = new ArrayList<>();
    private String[] columns = {"Nome", "CPF", "Email", "Telefone", "Data de nascimento"};
    UserDAO _userDao = new UserDAO();

    /**
     *
     * @param column
     * @return
     */
    @Override
    public String getColumnName(int column) {
        return columns[column];
    }

    /**
     *
     * @return
     */
    @Override
    public int getRowCount() {
        return users.size();
    }

    /**
     *
     * @return
     */
    @Override
    public int getColumnCount() {
        return columns.length;

    }

    /**
     *
     * @param rowIndex
     * @param columnIndex
     * @return
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return users.get(rowIndex).getNome();
            case 1:
                return users.get(rowIndex).getCpf();
            case 2:
                return users.get(rowIndex).getEmail();
            case 3:
                return users.get(rowIndex).getTelefone();
            case 4:
                return users.get(rowIndex).getDataNascimento();
        }
        return null;
    }

    /**
     *
     * @param user
     */
    public void addRow(User user) {
        this.users.add(user);
        this.fireTableDataChanged();

    }
    
    /**
     *
     * @param cpf
     * @param row
     */
    public void deleteRow(String cpf, int row) {
        boolean deleteExists = _userDao.deleteUser(cpf);
        if (deleteExists == true) {
               removeRow(row);
        }
    }

    /**
     *
     * @param row
     */
    public void removeRow(int row) {
        this.users.remove(row);
        this.fireTableRowsDeleted(row, row);
    }

}
