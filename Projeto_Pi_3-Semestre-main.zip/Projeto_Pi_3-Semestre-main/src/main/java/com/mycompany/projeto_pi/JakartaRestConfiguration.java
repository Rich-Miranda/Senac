package com.mycompany.projeto_pi;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("resources")
public class JakartaRestConfiguration extends Application {
   
}
