
package ENUM;

public enum Category {
    COMPUTADOR, PERIFERICO, CELULAR, ELETRODOMESTICO
}
